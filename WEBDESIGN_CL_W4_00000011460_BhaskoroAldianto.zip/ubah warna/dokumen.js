function atribut {
	document.getElementById("test1").style.backgroundColor = "grey";
}